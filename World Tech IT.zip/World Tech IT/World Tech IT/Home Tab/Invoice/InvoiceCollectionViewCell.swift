//
//  InvoiceCollectionViewCell.swift
//  World Tech IT
//
//  Created by Jay Kaushal on 20/01/21.
//

import UIKit

class InvoiceCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var payView: UIView!
    @IBOutlet weak var profileOmg: UIImageView!
    @IBOutlet weak var payStatusLbl: UILabel!
    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var invoiceDateLbl: UILabel!
    @IBOutlet weak var totalAmtLbl: UILabel!
    @IBOutlet weak var AmtWordsLbl: UILabel!
    @IBOutlet weak var backView: UIView!
    
    
}
